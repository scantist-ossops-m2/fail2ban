fail2ban.client.filterreader module
===================================

.. automodule:: fail2ban.client.filterreader
    :members:
    :undoc-members:
    :show-inheritance:
