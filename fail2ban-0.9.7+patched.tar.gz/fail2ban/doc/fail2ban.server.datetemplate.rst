fail2ban.server.datetemplate module
===================================

.. automodule:: fail2ban.server.datetemplate
    :members:
    :undoc-members:
    :show-inheritance:
