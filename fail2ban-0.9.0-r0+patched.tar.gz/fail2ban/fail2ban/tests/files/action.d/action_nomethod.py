
from fail2ban.server.action import ActionBase

class TestAction():

    def __init__(self, jail, name):
        pass

    def start(self):
        pass

Action = TestAction
