#!/usr/bin/env fail2ban-python
import sys
if sys.argv[1] == "10.0.0.1":
	exit(0)
exit(1)
